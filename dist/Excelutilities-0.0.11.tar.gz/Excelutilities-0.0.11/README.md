# excel-utilities

Contains some functions we have found useful when using python with Excel. Note that we are experimenting with using it as a python package and is not fully debugged yet

Currently:

## index_helpers
Contains some useful functions for working with Excel notation and other helper functions for indices. This is the sheet of functions we've found we re-use most, and are currently adding to once or twice a week.

## attach_data
A small function which allows you to select to columns, and a root file, and then attaches file locations as notes. 

## worksheet_remove_data
Is for removing data from a sheet and instead writing some summary data. The purpose of this is to remove sensitive information while keeping useful information for designing 
code and debuggong
